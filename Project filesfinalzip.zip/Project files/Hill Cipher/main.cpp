#include <iostream>
#include <string>
using namespace std;

const int N = 3; // size of the matrix key

// function to encrypt a message using the Hill Cipher
string encrypt(string message, int key[N][N]) {
    string cipher = "";
    for (int i = 0; i < message.length(); i += N) {
        for (int j = 0; j < N; j++) {
            int c = 0;
            for (int k = 0; k < N; k++) {
                c += (key[j][k] * (message[i + k] - 'A'));
            }
            cipher += (char)((c % 26) + 'A');
        }
    }
    return cipher;
}

// function to decrypt a ciphertext using the Hill Cipher
string decrypt(string cipher, int key[N][N]) {
    string message = "";
    int invKey[N][N];
    int det = key[0][0] * (key[1][1] * key[2][2] - key[2][1] * key[1][2]) - key[0][1] * (key[1][0] * key[2][2] - key[2][0] * key[1][2]) + key[0][2] * (key[1][0] * key[2][1] - key[2][0] * key[1][1]);
    det = det % 26;
    if (det < 0) {
        det += 26;
    }
    int invDet = 0;
    for (int i = 0; i < 26; i++) {
        if ((det * i) % 26 == 1) {
            invDet = i;
        }
    }
    invKey[0][0] = (key[1][1] * key[2][2] - key[2][1] * key[1][2]) * invDet % 26;
    invKey[0][1] = (key[0][2] * key[2][1] - key[0][1] * key[2][2]) * invDet % 26;
    invKey[0][2] = (key[0][1] * key[1][2] - key[0][2] * key[1][1]) * invDet % 26;
    invKey[1][0] = (key[1][2] * key[2][0] - key[1][0] * key[2][2]) * invDet % 26;
    invKey[1][1] = (key[0][0] * key[2][2] - key[0][2] * key[2][0]) * invDet % 26;
    invKey[1][2] = (key[0][2] * key[1][0] - key[0][0] * key[1][2]) * invDet % 26;
    invKey[2][0] = (key[1][0] * key[2][1] - key[1][1] * key[2][0]) * invDet % 26;
    invKey[2][1] = (key[0][1] * key[2][0] - key[0][0] * key[2][1]) * invDet % 26;
    invKey[2][1] = (key[0][1] * key[2][0] - key[0][0] * key[2][1]) * invDet % 26;
    invKey[2][2] = (key[0][0] * key[1][1] - key[0][1] * key[1][0]) * invDet % 26;
    for (int i = 0; i < cipher.length(); i += N) {
        for (int j = 0; j < N; j++) {
            int m = 0;
            for (int k = 0; k < N; k++) {
                m += (invKey[j][k] * (cipher[i + k] - 'A'));
            }
            message += (char)((m % 26) + 'A');
        }
    }
    return message;
}
int main() {
    string message;
    cout << "Enter a message to encrypt: ";
    getline(cin, message);
    int key[N][N];
    cout << "Enter the 3x3 matrix key: ";
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cin >> key[i][j];
        }
    }
    string cipher = encrypt(message, key);
    cout << "Encrypted message: " << cipher << endl;
    cout << "Decrypted message: " << decrypt(cipher, key) << endl;
    return 0;
}
