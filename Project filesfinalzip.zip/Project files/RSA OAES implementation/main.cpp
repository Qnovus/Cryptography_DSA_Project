#include <iostream>
#include <string>
#include <cryptlib.h>
#include <osrng.h>
#include <rsa.h>
#include <oaep.h>

using namespace std;
using namespace CryptoPP;

int main() {
    //generate a new RSA key pair
    AutoSeededRandomPool rng;
    RSA::PrivateKey privkey;
    privkey.GenerateRandomWithKeySize(rng, 2048);
    RSA::PublicKey pubkey(privkey);

    //encryption
    string plaintext = "This is the message to be encrypted";
    byte ciphertext[privkey.MaxEncryptOutputLength()];
    size_t ciphertextLength = 0;
    OAEP<SHA256>::Encrypt(rng, pubkey, plaintext.data(), plaintext.size(), ciphertext, &ciphertextLength);

    //decryption
    byte decryptedtext[privkey.MaxDecryptInputLength()];
    size_t decryptedtextLength = 0;
    OAEP<SHA256>::Decrypt(rng, privkey, ciphertext, ciphertextLength, decryptedtext, &decryptedtextLength);

    cout << "Original message: " << plaintext << endl;
    cout << "Encrypted message: ";
    for (size_t i = 0; i < ciphertextLength; i++) {
        printf("%02x", ciphertext[i]);
    }
    cout << endl;
    cout << "Decrypted message: ";
    for (size_t i = 0; i < decryptedtextLength; i++) {
        printf("%c", decryptedtext[i]);
    }
    cout << endl;
    return 0;
}
