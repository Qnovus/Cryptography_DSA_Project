#include<iostream>
#include<string>
using namespace std;
void encrypt(int,string,int);

void decrypt(int, string,int);

void menu();

int gcd(int, int);

int modInverse(int, int);

bool checkInput(string );

int main()
{
    menu();
}

 

void menu()
{
    cout<<"--------MENU--------"<<endl;
    int n;
    
    cout<<"1- Enter 1 to  encrypt a message"<<endl;
    
    cout<<"2- Enter 2 to  decrypt a message"<<endl;
    
    cin>>n;
    
    cout << "Enter the string:" << endl; //taking string as an input
    getchar();
    string a;
    
    getline(cin,a);
    
    if(!checkInput(a))
        
    {
        
        menu();
        
    }
    
    int shift;
    
    int stretch;
    
    cout << "Enter the number of shifts:" << endl;
    cin >> shift;
    
    if (shift < 0)
        
    {
        shift = 26 + shift;
    }
    
    cout << "Enter the stretching factor:" << endl;
    
    cin >> stretch;
    
    if(stretch <=0)
    {
        cout << "Stretching factor must be positive." << endl;
        menu();
    }
    if (gcd(stretch, 26) != 1) {
        cout << "Stretching factor must be coprime with 26." << endl;
        menu();
    }
    
    switch(n)
    {
        case 1:
        {
            encrypt(shift,a,stretch);
            menu();
            break;
        }
        case 2:
        {
            decrypt(shift,a,stretch);
            menu();
            break;
        }
        default:
            cout << "Enter either 1 or 2";
            menu();
    }
}



bool checkInput(string input)
{
    for (int i = 0; i < input.length(); i++)
    {
        if (!isalpha(input[i]) && !isspace(input[i]))
        {
            cout << "Invalid input. Please enter only letters and spaces." << endl;
            return false;
        }
        
    }
    return true;
}

int modInverse(int a, int m) // a is the number m is the modulo operation
{
    int m0 = m;
    int y = 0, x = 1;
    if (m == 1)
    return 0;
    while (a > 1)
    {
        int q = a / m;
        int t = m;
        m = a % m, a = t;
        t = y;
        y = x - q * y;
        x = t;
    }
    if (x < 0)
        x += m0;

    return x;

}
// Function for iterative Euclidean Algorithm

int gcd(int a, int b) {

    int temp;

    while (b != 0)

    {

        temp = a % b;

        a = b;

        b = temp;

    }

    return abs(a);

}

 

void encrypt(int shift, string b,int stretch)

{
    for (int i = 0; i < b.length(); i++)
    {
        if(!isupper(b[i]))
        {
            b[i] = b[i] - 97;   //assigning each alphabet a number from 0-25
            b[i] = (stretch*b[i]+ shift) % 26;   //scaling each alphabet and then shifting it to the right
            b[i] = b[i] + 97;  //converting back to alphabets
        }
        else
        {
            b[i] = b[i] - 65;   //assigning each alphabet a number from 0-25
            b[i] = (stretch*b[i]+ shift) % 26;   //scaling each alphabet and then shifting it to the right
            b[i] = b[i] + 65;
        }
    }

    cout << "The encrypted message is: ";
    for (int i=0;i<b.length();i++)
    {
      if(!isspace(b[i]))
      {
        cout << b[i];
      }

    }
    cout << endl;

    cout<<"Your shifts were: "<<shift << endl;

    cout<<"Your stretching factor was: "<< stretch << endl;

}

void decrypt(int shift, string b,int stretch)

{

    int a_inv=modInverse(stretch, 26);

    for (int i = 0; i < b.length(); i++)

    {
        
        if (!isspace(b[i]))
        {
            
            if(!isupper(b[i]))
            {
                b[i] = b[i] - 97;    //assigning each alphabet a number from 0-25
                
                b[i] = (b[i]-shift+26)*a_inv % 26;  //shifting each alphabet to left and then inverse scaling it
                
                b[i] = b[i] + 97;   //converting back to alphabets
            }
            else
            {
                b[i] = b[i] - 65;    //assigning each alphabet a number from 0-25
                
                b[i] = (b[i]-shift+26)*a_inv % 26;  //shifting each alphabet to left and then inverse scaling it
                
                b[i] = b[i] + 65;   //converting back to alphabets
            }
            
        }

                
     }

    

    cout << "The decrypted message is: " << b << endl;

}
