#include<iostream>
#include<string>
using namespace std;

 

void encrypt(int,string);
void decrypt(int, string);
void menu();

 

int main()
{
    menu();
 

}

void menu()
{
    cout<<"--------MENU--------"<<endl;

    int n;
    cout<<"1- Enter 1 to  encrypt the message"<<endl;
    cout<<"2- Enter 2 to  decrypt the message"<<endl;
    cin>>n;
    int shift;
    cout << "Enter any string:" << endl; //taking string as an input
    string* a = new string;
    getchar();
    getline(cin, *a);
    switch(n)
    {
        case 1:
        {
            cout << "Enter the number of shifts:" << endl;
            cin >> shift;
            encrypt(shift,*a);
            getchar();
            menu();
        }
        case 2:
        {
            cout << "Enter the password to decrypt the message:" << endl;
            cin >> shift;
            decrypt(shift,*a);
            getchar();
            menu();
        }
    }
    
}
 

void encrypt(int shift, string b)
{
    
    for (int i = 0; i < b.length(); i++)
    {
        if (!isspace(b[i]))
        {
            b[i]=tolower(b[i]);  //converting all the alphabets into lower case
            b[i] = b[i] - 97;   //assigning each alphabet a number from 0-25
            b[i] = (b[i] + shift+26) % 26;   //shifting each alphabet to right by passed value
            b[i] = b[i] + 97;  //converting back to alphabets
        }
    }
    cout << "The encrypted message is: " << b << endl;
    cout<<"Your password is: "<<shift<<endl;
    
}
void decrypt(int shift, string b)
{
    for (int i = 0; i < b.length(); i++)
    {
        if (!isspace(b[i]))
        {
            b[i]=tolower(b[i]);  //converting all the alphabets into lower case
            b[i] = b[i] - 97;    //assigning each alphabet a number from 0-25
            b[i] =(b[i]-shift+26) % 26;  //shifting each alphabet to left by passed value
            b[i] = b[i] + 97;   //converting back to alphabets
        }
    }
    cout << "The decrypted message is:" << b << endl;
}
