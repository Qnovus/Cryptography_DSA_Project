#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <time.h>
using namespace std;

//function to generate a random prime number
long long generatePrime() {
    srand(time(NULL));
    long long prime = rand() % 10000 + 1000;
    while (!isPrime(prime)) {
        prime = rand() % 10000 + 1000;
    }
    return prime;
}

//function to check if a number is prime
bool isPrime(long long n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    for (int i = 5; i * i <= n; i = i + 6)
        if (n % i == 0 || n % (i + 2) == 0)
            return false;
    return true;
}

//function to calculate the modular inverse
long long modInverse(long long a, long long m) {
    long long m0 = m, t, q;
    long long x0 = 0, x1 = 1;
    if (m == 1)
        return 0;
    while (a > 1) {
        q = a / m;
        t = m;
        m = a % m, a = t;
        t = x0;
        x0 = x1 - q * x0;
        x1 = t;
    }
    if (x1 < 0)
        x1 += m0;
    return x1;
}

//function to calculate the gcd
long long gcd(long long a, long long b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

//function to encrypt the message
string encrypt(string message, long long e, long long n) {
    string cipher = "";
    for (int i = 0; i < message.length(); i++) {
        long long c = pow(message[i], e);
        c = c % n;
        cipher += (char)c;
    }
    return cipher;
}

//function to decrypt the message
string decrypt(string cipher, long long d, long long n) {
    string message = "";
    for (int i = 0; i < cipher.length(); i++) {
        long long m = pow(cipher[i], d);
        m = m % n;
        message += (char)m;
    }
    return message;
}

int main() {
    string message;
    cout << "Enter the message to encrypt: ";
    getline(cin, message);
    long long p = generatePrime();
    long long q = generatePrime();
    long long n = p * q;
    long long phi = (p - 1) * (q - 1);
    long long e = rand() % phi + 1;
    while (gcd(e, phi) != 1) {
        e = rand() % phi + 1;
       }
    long long d = modInverse(e, phi);
    string cipher = encrypt(message, e, n);
    cout << "Encrypted message: " << cipher << endl;
    cout << "Decrypted message: " << decrypt(cipher, d, n) << endl;
    return 0;
}
